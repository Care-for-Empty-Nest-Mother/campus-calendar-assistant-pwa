/* 校历小助手 Service Worker：缓存核心资源，离线可用 */
const CACHE = 'xpu-keli-v4';
const ASSETS = [
  './',
  './index.html',
  './data.js',
  './manifest.json',
  './icons/apple-touch-icon.png',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-512-maskable.png'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(ks => {
      const olds = ks.filter(k => k !== CACHE).map(k => caches.delete(k));
      return Promise.all(olds);
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  /* 页面导航永远走网络优先：保证更新即时可见，离线时才回落缓存 */
  if (e.request.mode === 'navigate' || url.pathname.endsWith('/index.html')) {
    e.respondWith(
      fetch(e.request).then(res => {
        try {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, copy));
        } catch (err) { /* ignore */ }
        return res;
      }).catch(() => caches.match(e.request).then(h => h || caches.match('./index.html')))
    );
    return;
  }
  e.respondWith(
    caches.match(e.request).then(hit => {
      if (hit) return hit;
      return fetch(e.request).then(res => {
        try {
          if (url.origin === self.location.origin) {
            const copy = res.clone();
            caches.open(CACHE).then(c => c.put(e.request, copy));
          }
        } catch (err) { /* ignore */ }
        return res;
      });
    })
  );
});

